package sii.maroc;

import java.util.HashMap;

public class Vehicles {

	private String carbVehicle;
	private String marcheVehicle;
	private String vitesseVehicle;
	private String type;

	public Vehicles(String carburants) {

		this.carbVehicle = carburants;
		// TODO Auto-generated constructor stub
	}

	public String TypeMessage(String typeCar)
	{
		HashMap<String, String> cars = new HashMap<String, String>();
		cars.put("CAR", "DOORS OK, MOVING. The CAR will consume 10.00 L");
		cars.put("TRUCK", "DOORS OK, MOVING. The TRUCK will consume 50.00 L");
		cars.put("MOTORSCYCLE", "DOORS OK, MOVING. The MOTORCYCLE will consume 3.00 L");

		return cars.get(typeCar);
	}
	
	
	public String move(String type, String carburant, String marche, String vitesse) {

		String NouvelleVitesse = vitesse.replaceAll("\\s+", "");
		String NouvelleMarche = marche.replaceAll("\\s+", "");

		if (this.carbVehicle.contains(carburant) && this.type.equals(type) && this.marcheVehicle.equals(NouvelleMarche)
				&& this.vitesseVehicle.equals(NouvelleVitesse)) {
			return  TypeMessage(type) ;
		}

		return "Vehicule non Existe";

	}

	public String getCarbVehicle() {
		return carbVehicle;

	}

	public void setCarbVehicle(String carbVehicle) {
		this.carbVehicle = carbVehicle;
	}

	public String getMarcheVehicle() {
		return marcheVehicle;
	}

	public void setMarcheVehicle(String marcheVehicle) {
		this.marcheVehicle = marcheVehicle;
	}

	public String getVitesseVehicle() {
		return vitesseVehicle;
	}

	public void setVitesseVehicle(String vitesseVehicle) {
		this.vitesseVehicle = vitesseVehicle;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}

